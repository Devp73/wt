<?php
if(isset($_POST['sub'])){
    $num1 = $_POST['n1'];
    $num2 = $_POST['n2'];
    $oprnd = $_POST['sub'];
    if($oprnd == "add")
        $ans = $num1 + $num2;
    else if($oprnd == "subtract")
        $ans = $num1 - $num2;
    else if($oprnd == "multiply")
        $ans = $num1 * $num2;
    else if($oprnd == "divide")
        $ans = $num1 / $num2;
}
?>

<html>
<body>
    <form method="post">
        <h1>Simple Calculator</h1>
        <br>
        <input name="n1" value="">First Number
        <br>
        <input name="n2" value="">Second Number
        <br>
        <input type='text' value="<?php echo $ans; ?>" readonly>Result<br>
        <input type="submit" name="sub" value="add">
        <input type="submit" name="sub" value="subtract">
        <input type="submit" name="sub" value="multiply">
        <input type="submit" name="sub" value="divide">
    </form>
</body>
</html>
